from fastapi import FastAPI

# 🔐 Firebase Admin
import firebase_admin
from firebase_admin import credentials, auth

# Routers
from app.api.routes import health, users, scans, recycling_centers

# Database
from app.db.session import engine
from app.db.base import Base

# Import models (مهم عشان الجداول تتعمل)
from app.models import user, scan, recycling_center


app = FastAPI(title="Smart Pre Recycling Backend")


# ==============================
# 🔐 Initialize Firebase Admin
# ==============================

cred = credentials.Certificate(
    "smart-pre-recycling-firebase-adminsdk-fbsvc-946269cdfb.json"
)

firebase_admin.initialize_app(cred)


# ==============================
# 🗄 Create tables
# ==============================

Base.metadata.create_all(bind=engine)


# ==============================
# 📌 Include routers
# ==============================

app.include_router(health.router)
app.include_router(users.router)
app.include_router(scans.router)
app.include_router(recycling_centers.router)


@app.get("/")
def root():
    return {"message": "Backend + DB connected 🚀"}