from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.scan import Scan
from app.models.user import User

router = APIRouter(prefix="/scans", tags=["Scans"])


# CO2 calculation logic
def calculate_co2(material_type: str, weight: float):
    factors = {
        "plastic": 1.5,
        "paper": 0.8,
        "metal": 2.0,
        "glass": 0.5
    }

    factor = factors.get(material_type.lower(), 1.0)
    return weight * factor


# 🔹 Create Scan
@router.post("/")
def create_scan(
    user_id: int,
    material_type: str,
    weight: float,
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    co2_saved = calculate_co2(material_type, weight)

    new_scan = Scan(
        user_id=user_id,
        material_type=material_type,
        weight=weight,
        co2_saved=co2_saved
    )

    db.add(new_scan)

    # update user stats
    user.total_scans += 1
    user.total_co2_saved += co2_saved

    db.commit()
    db.refresh(new_scan)

    return new_scan


# 🔥 NEW: Get All Scans For User
@router.get("/user/{user_id}")
def get_user_scans(user_id: int, db: Session = Depends(get_db)):
    scans = db.query(Scan).filter(Scan.user_id == user_id).all()
    return scans